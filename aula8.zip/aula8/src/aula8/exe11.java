
package aula8;

import java.util.Scanner;


public class exe11 {


  
    public static void main(String[] args) {
       
        
        Scanner sc = new Scanner (System.in);
        double  n = 1;
        System.out.println("digite um numero :" );
        n = sc.nextInt();
       double  soma = 0 ; 
        
       for (double  i = 1 ; i< n ; i++){
        if ( i%2 == 0) {
            soma = soma  - (1/i);
          }
          
        else if  ( i%2 != 0){
            soma = soma  + (1/i);
       
        }
        
           
    
    
    
    
    
    
    
    
    }
               System.out.println(soma );

    
    }
    
}
