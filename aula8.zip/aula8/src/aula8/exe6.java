
package aula8;

import java.util.Scanner;


public class exe6 {
    
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner ( System.in );
        
       String  nome ;
       String nome2 = "";
       int     idade , idade2=0 ;
       char   sexo , sexo2 ;
       int i =0 ;
        
        
        
        do {
              System.out.print("digite o nome :");
              nome = sc.next();
              System.out.print("digite a idade :");
              idade = sc.nextInt();
              System.out.print("digite o sexo :");
              sexo = sc.next().charAt(0); 
             System.out.println("");

           i++;
              
           if ( idade > idade2){
            idade2 = idade ;
            nome2 = nome ;
            sexo2 = sexo ;
             
           
           
           
           }
           
        }
               while (i<2); 
           
                   
      
        System.out.println("aluno mais velho");
        System.out.println("nome aluno " + nome);
        System.out.println("nome idade " + idade);
        System.out.println("nome sexo  " + sexo  );
  
    
    
                   
        }

        }
       
    