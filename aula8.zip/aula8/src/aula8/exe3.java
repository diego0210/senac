
package aula8;

import java.util.Scanner;


public class exe3 {
  
    
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        int n ;
        int soma =0 ;
        
        for (int i =0 ; i <10 ; i++ ){
            System.out.print("Digite um numero:");
           n=sc.nextInt();
            
       if ( n > soma ){
        soma = n ;
        
        
        }
        
    }
        System.out.println("numero maior :" + soma );
    
}
}